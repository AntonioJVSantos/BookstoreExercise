public interface Printable {
    public void print();
    
}
